export class RefreshDto {
  refresh_token: string;
}